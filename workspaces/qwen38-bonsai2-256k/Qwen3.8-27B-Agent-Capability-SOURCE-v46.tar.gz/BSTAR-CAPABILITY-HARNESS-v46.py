#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
千问3.8 27B1 — Bonsai 2 27B 能力边界/极限时间统一测试运行器 v4.6

Modes:
  self-test      Zero-GPU structural closure of all 1018 units.
  materialize    Write all executable fixture contracts as JSONL.
  frontier-plan  Write the pairwise-minimal initial reality frontier (144 units).
  probe          Execute one model-decision fixture against a running local llama-server.
  reality-frontier
                 Execute the model-decision portion of the frozen frontier against a running
                 local llama-server; runtime/cache/memory probes are emitted as deterministic
                 adapter jobs for the existing Bonsai runtime runner.

Important:
  - No model download/build/system/proxy mutation is performed here.
  - The runner is a controller/harness. It never lets the model redesign the frozen test.
  - Full 1018 pool remains available for boundary expansion after failures/instability.
"""
from __future__ import annotations
import argparse, hashlib, json, os, random, sys, tempfile, time
from pathlib import Path
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
DEFAULT_SUITE = HERE / "Qwen3.8-27B-Bstar-Executor-Cert-Suite-v3.json"
DEFAULT_OVERLAY = HERE / "Qwen3.8-27B-Agent-Capability-Overlay-v46.json"
CTX_MAX = 262144

KIND_KEYS = [
    ("atomic", "atomic_cases"),
    ("jev", "jev_cases"),
    ("thinking", "thinking_cases"),
    ("long", "long_workflows"),
    ("cache", "cache_trials"),
    ("memory", "memory_trials"),
]
EXPECTED_COUNTS = {"atomic":592,"jev":240,"thinking":96,"long":18,"cache":48,"memory":24}
EXPECTED_TOTAL = 1018

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def stable_hash(obj) -> str:
    return sha256_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",",":")))

def flatten_units(suite):
    rows=[]
    for kind,key in KIND_KEYS:
        for x in suite[key]:
            rows.append((kind,x))
    return rows

def route_budget(route, overlay):
    return int(overlay["token_contract"]["reasoning_budget_tokens"].get(route,0))

def nominal_prompt_tokens(band, overlay):
    return int(overlay["token_contract"]["nominal_prompt_targets"].get(band,4096))

def token_envelope(kind, unit, overlay):
    tc=overlay["token_contract"]
    output=int(tc["output_reserve_tokens"])
    guard=int(tc["guard_tokens"])
    if kind=="atomic":
        route=unit["reasoning_route"]
        reasoning=route_budget(route,overlay)
        tool=int(tc["tool_schema_reserve_tokens"][unit["tool_family"]])
        nominal=nominal_prompt_tokens(unit["context_band"],overlay)
        cap=CTX_MAX-reasoning-tool-output-guard
        effective=min(nominal,cap)
        semantics="PROMPT_BAND" if nominal<=cap else "NEAR_BOUNDARY_TOTAL_ENVELOPE"
        return {"prompt_target_tokens":effective,"nominal_prompt_tokens":nominal,
                "reasoning_budget_tokens":reasoning,"tool_schema_reserve_tokens":tool,
                "output_reserve_tokens":output,"guard_tokens":guard,
                "total_reserved_tokens":effective+reasoning+tool+output+guard,
                "semantics":semantics}
    if kind=="jev":
        return {"prompt_target_tokens":2048,"reasoning_budget_tokens":0,
                "tool_schema_reserve_tokens":128,"output_reserve_tokens":128,"guard_tokens":256,
                "total_reserved_tokens":2560,"semantics":"SMALL_STRUCTURED_DECISION"}
    if kind=="thinking":
        reasoning=int(unit["budget_tokens"])
        prompt=4096
        return {"prompt_target_tokens":prompt,"reasoning_budget_tokens":reasoning,
                "tool_schema_reserve_tokens":128,"output_reserve_tokens":256,"guard_tokens":512,
                "total_reserved_tokens":prompt+reasoning+896,"semantics":"THINKING_ROUTE"}
    if kind=="long":
        prof=unit["context_growth_profile"]
        prompt={"bounded_working_set":65536,"progressive":131072,"near_boundary":245760}[prof]
        reasoning=2048
        return {"prompt_target_tokens":prompt,"reasoning_budget_tokens":reasoning,
                "tool_schema_reserve_tokens":768,"output_reserve_tokens":512,"guard_tokens":1024,
                "total_reserved_tokens":prompt+reasoning+2304,"semantics":"WORKFLOW_WORKING_SET"}
    if kind=="cache":
        prompt=nominal_prompt_tokens(unit["context_band"],overlay)
        return {"prompt_target_tokens":prompt,"reasoning_budget_tokens":0,
                "tool_schema_reserve_tokens":0,"output_reserve_tokens":128,"guard_tokens":512,
                "total_reserved_tokens":prompt+640,"semantics":"RUNTIME_CACHE_PROBE"}
    if kind=="memory":
        prompt=nominal_prompt_tokens(unit["context_band"],overlay)
        return {"prompt_target_tokens":prompt,"reasoning_budget_tokens":0,
                "tool_schema_reserve_tokens":0,"output_reserve_tokens":128,"guard_tokens":512,
                "total_reserved_tokens":prompt+640,"semantics":"RUNTIME_MEMORY_PROBE"}
    raise KeyError(kind)

def atomic_expected(unit):
    fm=unit["failure_mode"]
    retries=int(unit["plan_contract"]["max_retries"])
    if fm=="none": decision="EXECUTE"
    elif fm=="retryable": decision="RETRY" if retries>0 else "STOP"
    elif fm=="hard_fail": decision="STOP"
    elif fm=="ambiguous_receipt": decision="VERIFY"
    elif fm=="stale_state": decision="REFRESH_STATE"
    elif fm=="partial_write": decision="READBACK_VERIFY"
    elif fm=="timeout": decision="RETRY" if retries>0 else "STOP"
    elif fm=="schema_error": decision="REJECT"
    else: decision="STOP"
    return {
        "decision":decision,
        "tool_family":unit["tool_family"],
        "reasoning_route":unit["reasoning_route"],
        "terminal":"STOP_PASS" if fm not in ("hard_fail","schema_error") else "STOP_BLOCKED"
    }

def jev_expected(unit):
    seed=int(unit["seed"])
    rng=random.Random(seed)
    choices=["A","B","C","D"]
    # deterministic hidden score; prompt exposes the component values, not the answer.
    vals={c:rng.randrange(10,100) for c in choices}
    # confidence band controls the margin without changing boundedness.
    best=max(vals,key=vals.get)
    if unit["confidence_band"]=="high":
        vals[best]=max(vals.values())+40
    elif unit["confidence_band"]=="medium":
        vals[best]=max(vals.values())+12
    else:
        vals[best]=max(vals.values())+1
    best=max(vals,key=vals.get)
    return vals, {
        "decision":best,
        "route":"THINKING" if unit["confidence_band"]=="low" else "FAST",
        "reason_code":"MAX_SCORE"
    }

def build_fixture(kind,unit,overlay):
    env=token_envelope(kind,unit,overlay)
    cid=unit["id"]
    common={"case_id":cid,"kind":kind,"handler":None,"token_envelope":env,
            "source_hash":stable_hash(unit),"model_reality_required":bool(unit.get("model_reality_required",True))}
    if kind=="atomic":
        exp=atomic_expected(unit)
        common.update({
          "handler":"ATOMIC_AGENT_DECISION",
          "input":{
            "plan_immutable":True,
            "domain":unit["domain"],"variant":unit["variant"],"plan_shape":unit["plan_shape"],
            "tool_family":unit["tool_family"],"failure_mode":unit["failure_mode"],
            "max_retries":unit["plan_contract"]["max_retries"],
            "receipt":{"status":unit["failure_mode"],"seed":unit["fixture"]["seed"]},
            "allowed_decisions":["EXECUTE","RETRY","STOP","VERIFY","REFRESH_STATE","READBACK_VERIFY","REJECT"]
          },
          "expected":exp,
          "oracle":unit["oracle"],
          "stop_condition":"exact decision/schema + frozen invariants"
        })
    elif kind=="jev":
        vals,exp=jev_expected(unit)
        common.update({
          "handler":"JEV_OR_LOCAL_STRUCTURED_DECISION",
          "input":{"decision_type":unit["type"],"values":vals,"ambiguity":unit["ambiguity"],
                   "confidence_band":unit["confidence_band"],"choices":list(vals)},
          "expected":exp,"oracle":unit["oracle"],
          "fallback":"LOCAL_AGENT" if unit["confidence_band"]=="low" else "LOCAL_AGENT_ON_JEV_FAILURE",
          "stop_condition":"exact bounded decision; no freeform plan"
        })
    elif kind=="thinking":
        common.update({
          "handler":"THINKING_ROUTE_DECISION",
          "input":{"trigger":unit["trigger"],"allowed_routes":["OFF","LOW_512","MEDIUM_2048","HIGH_8192"]},
          "expected":{"route":unit["route"],"budget_tokens":unit["budget_tokens"]},
          "oracle":unit["oracle"],"stop_condition":"exact route within budget"
        })
    elif kind=="long":
        steps=int(unit["steps"])
        common.update({
          "handler":"LONG_WORKFLOW_CONTROLLER",
          "input":{"archetype":unit["archetype"],"steps":steps,"checkpoints":unit["checkpoints"],
                   "failure_schedule":unit["failure_schedule"],"context_growth_profile":unit["context_growth_profile"],
                   "plan_hash":sha256_text(cid+":PLAN")},
          "expected":{"completed_steps":steps,"failures_handled":unit["injected_failures"],
                      "plan_drift":0,"false_pass":0,"terminal":"STOP_PASS"},
          "oracle":{"required_invariants":unit["required_invariants"]},
          "stop_condition":"all checkpoint receipts + final manifest exact"
        })
    elif kind=="cache":
        common.update({
          "handler":"CACHE_RUNTIME_PROBE",
          "input":{"context_band":unit["context_band"],"mode":unit["mode"],"kv":unit["kv"],
                   "server_flags":unit["server_flags"],"cache_prompt":unit["request_cache_prompt"]},
          "expected":{"measure":unit["oracle"]["measure"],"sampling_match":True},
          "oracle":unit["oracle"],"stop_condition":"cache metrics explicit; no latency-only inference"
        })
    elif kind=="memory":
        common.update({
          "handler":"MEMORY_RUNTIME_PROBE",
          "input":{"context_band":unit["context_band"],"kv":unit["kv"],"batch_profile":unit["batch_profile"]},
          "expected":{"no_oom":True,"no_cuda_alloc_fail":True,"no_cpu_layer_fallback":True},
          "oracle":unit["oracle"],"stop_condition":"resource gate measured"
        })
    else:
        raise KeyError(kind)
    return common

def validate_fixture(fx):
    req=["case_id","kind","handler","token_envelope","input","expected","oracle","stop_condition"]
    missing=[x for x in req if x not in fx]
    if missing: return False,"MISSING:"+",".join(missing)
    e=fx["token_envelope"]
    if int(e["total_reserved_tokens"])>CTX_MAX:
        return False,f"TOKEN_OVERFLOW:{e['total_reserved_tokens']}"
    if not fx["handler"] or not fx["stop_condition"]:
        return False,"UNBOUND_HANDLER_OR_STOP"
    return True,"PASS"

def observed_pair_set(arr,factors):
    s=set()
    for x in arr:
        for i,f1 in enumerate(factors):
            for f2 in factors[i+1:]:
                s.add((f1,f2,str(x[f1]),str(x[f2])))
    return s

def anchor_coverage(suite,overlay):
    out={}
    cfg={
      "atomic_cases":["domain","context_band","tool_family","failure_mode","plan_shape","reasoning_route"],
      "jev_cases":["type","confidence_band","ambiguity"],
      "thinking_cases":["route","trigger","budget_tokens"],
      "long_workflows":["steps","archetype","context_growth_profile"],
      "cache_trials":["context_band","mode","kv","request_cache_prompt"],
      "memory_trials":["context_band","kv","batch_profile"],
    }
    for key,factors in cfg.items():
        arr=suite[key]
        ids=set(overlay["reality_frontier_plan"]["anchor_ids"][key])
        sub=[x for x in arr if x["id"] in ids]
        full=observed_pair_set(arr,factors)
        got=observed_pair_set(sub,factors)
        out[key]={"selected":len(sub),"required_pairs":len(full),"covered_pairs":len(got),
                  "missing_pairs":len(full-got),"pass":full<=got}
    return out

def self_test(suite,overlay,outdir):
    t0=time.perf_counter()
    counts={}
    units=flatten_units(suite)
    for kind,key in KIND_KEYS: counts[kind]=len(suite[key])
    errors=[]
    if counts!=EXPECTED_COUNTS: errors.append(f"COUNT_MISMATCH:{counts}")
    if len(units)!=EXPECTED_TOTAL: errors.append(f"TOTAL_MISMATCH:{len(units)}")
    ids=[u["id"] for _,u in units]
    if len(set(ids))!=len(ids): errors.append("DUPLICATE_CASE_ID")
    fixtures=[]
    for kind,u in units:
        fx=build_fixture(kind,u,overlay)
        ok,msg=validate_fixture(fx)
        if not ok: errors.append(f"{u['id']}:{msg}")
        fixtures.append(fx)
    correction_ids={x["id"] for x in overlay["corrected_atomic_cases"]}
    actual_corr={fx["case_id"] for fx in fixtures if fx["kind"]=="atomic" and fx["token_envelope"]["semantics"]=="NEAR_BOUNDARY_TOTAL_ENVELOPE"}
    if correction_ids!=actual_corr:
        errors.append(f"CORRECTION_SET_MISMATCH expected={len(correction_ids)} actual={len(actual_corr)}")
    if len(actual_corr)!=16: errors.append(f"CORRECTION_COUNT_NOT_16:{len(actual_corr)}")
    coverage=anchor_coverage(suite,overlay)
    if not all(v["pass"] for v in coverage.values()):
        errors.append("FRONTIER_PAIRWISE_COVERAGE_FAIL")
    outdir.mkdir(parents=True,exist_ok=True)
    manifest=outdir/"SELFTEST-FIXTURES.jsonl"
    with manifest.open("w",encoding="utf-8") as f:
        for fx in fixtures:
            f.write(json.dumps(fx,ensure_ascii=False,separators=(",",":"))+"\n")
    report={
      "task":"千问3.8 27B1 本地智能体能力边界 v4.6 零GPU闭环自检",
      "gpu_runs":0,"network_calls":0,"model_calls":0,
      "suite_units":len(fixtures),"suite_counts":counts,
      "token_corrections":len(actual_corr),"token_correction_ids":sorted(actual_corr),
      "frontier_pairwise_coverage":coverage,
      "frontier_initial_units":overlay["reality_frontier_plan"]["total_initial_units"],
      "fixture_manifest_sha256":hashlib.sha256(manifest.read_bytes()).hexdigest(),
      "elapsed_ms":round((time.perf_counter()-t0)*1000,3),
      "execution_chain_closed":not errors,
      "runner_binding_closed":not errors,
      "result":"PASS" if not errors else "FAIL",
      "errors":errors
    }
    (outdir/"SELFTEST-RESULT.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    return report

def materialize(suite,overlay,outdir,only_ids=None):
    outdir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for kind,u in flatten_units(suite):
        if only_ids is not None and u["id"] not in only_ids: continue
        rows.append(build_fixture(kind,u,overlay))
    p=outdir/"FIXTURES.jsonl"
    with p.open("w",encoding="utf-8") as f:
        for x in rows:f.write(json.dumps(x,ensure_ascii=False,separators=(",",":"))+"\n")
    return {"count":len(rows),"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}

def render_model_prompt(fx):
    compact={
      "case_id":fx["case_id"],
      "task":"Choose the exact frozen decision. Return JSON only. Do not redesign the plan.",
      "input":fx["input"],
      "required_output_keys":sorted(fx["expected"].keys())
    }
    return json.dumps(compact,ensure_ascii=False,separators=(",",":"))

def extract_completion_text(resp):
    if isinstance(resp,dict):
        if resp.get("content") is not None:return str(resp["content"])
        if isinstance(resp.get("choices"),list) and resp["choices"]:
            c=resp["choices"][0]
            if isinstance(c,dict):
                if c.get("text") is not None:return str(c["text"])
                m=c.get("message")
                if isinstance(m,dict) and m.get("content") is not None:return str(m["content"])
    return ""

def post_completion(endpoint,prompt,timeout=180):
    body={"prompt":prompt,"n_predict":256,"temperature":0,"seed":1,"stream":False,"cache_prompt":True}
    req=Request(endpoint.rstrip("/")+"/completion",
                data=json.dumps(body,separators=(",",":")).encode("utf-8"),
                headers={"Content-Type":"application/json"},method="POST")
    t0=time.perf_counter()
    with urlopen(req,timeout=timeout) as r: raw=r.read()
    resp=json.loads(raw.decode("utf-8"))
    return resp,(time.perf_counter()-t0)*1000

def verify_model_result(fx,text):
    try:
        obj=json.loads(text.strip())
    except Exception as e:
        return False,{"code":"INVALID_JSON","detail":str(e),"raw":text[:500]}
    exp=fx["expected"]
    # Model-decision fixtures use exact subset equality; extra keys are rejected.
    if set(obj)!=set(exp):
        return False,{"code":"KEY_SET_MISMATCH","expected_keys":sorted(exp),"got_keys":sorted(obj)}
    if obj!=exp:
        return False,{"code":"VALUE_MISMATCH","expected":exp,"got":obj}
    return True,{"code":"PASS"}

def probe_one(suite,overlay,case_id,endpoint):
    table={u["id"]:(kind,u) for kind,u in flatten_units(suite)}
    if case_id not in table: raise SystemExit("unknown case id")
    kind,u=table[case_id]
    fx=build_fixture(kind,u,overlay)
    if kind in ("cache","memory"):
        return {"case_id":case_id,"status":"ADAPTER_JOB","handler":fx["handler"],"fixture":fx,
                "note":"runtime probe is executed by the frozen Bonsai runtime adapter, not as a text-only model decision"}
    prompt=render_model_prompt(fx)
    resp,ms=post_completion(endpoint,prompt)
    text=extract_completion_text(resp)
    ok,detail=verify_model_result(fx,text)
    return {"case_id":case_id,"kind":kind,"pass":ok,"e2e_ms":round(ms,3),"detail":detail,"output":text}

def frontier_ids(overlay):
    out=[]
    for _,key in KIND_KEYS:
        out.extend(overlay["reality_frontier_plan"]["anchor_ids"][key])
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--mode",choices=["self-test","materialize","frontier-plan","probe","reality-frontier"],default="self-test")
    ap.add_argument("--suite",default=str(DEFAULT_SUITE))
    ap.add_argument("--overlay",default=str(DEFAULT_OVERLAY))
    ap.add_argument("--out",default=str(HERE/"results-v46"))
    ap.add_argument("--case-id")
    ap.add_argument("--endpoint",default="http://127.0.0.1:18088")
    ap.add_argument("--max-model-cases",type=int,default=0,
                    help="0 means all selected model-decision frontier cases; cache/memory remain adapter jobs")
    args=ap.parse_args()
    suite=load_json(Path(args.suite)); overlay=load_json(Path(args.overlay)); out=Path(args.out)

    if args.mode=="self-test":
        r=self_test(suite,overlay,out)
        print(json.dumps(r,ensure_ascii=False,indent=2))
        raise SystemExit(0 if r["result"]=="PASS" else 2)
    if args.mode=="materialize":
        print(json.dumps(materialize(suite,overlay,out),ensure_ascii=False,indent=2));return
    if args.mode=="frontier-plan":
        ids=set(frontier_ids(overlay))
        r=materialize(suite,overlay,out,ids)
        r["frontier_counts"]=overlay["reality_frontier_plan"]["anchor_counts"]
        print(json.dumps(r,ensure_ascii=False,indent=2));return
    if args.mode=="probe":
        if not args.case_id: raise SystemExit("--case-id required")
        r=probe_one(suite,overlay,args.case_id,args.endpoint)
        print(json.dumps(r,ensure_ascii=False,indent=2));return
    if args.mode=="reality-frontier":
        table={u["id"]:(kind,u) for kind,u in flatten_units(suite)}
        ids=frontier_ids(overlay)
        results=[]; model_done=0
        out.mkdir(parents=True,exist_ok=True)
        t0=time.perf_counter()
        for cid in ids:
            kind,u=table[cid]
            fx=build_fixture(kind,u,overlay)
            if kind in ("cache","memory"):
                results.append({"case_id":cid,"kind":kind,"status":"ADAPTER_JOB","handler":fx["handler"],"pass":None})
                continue
            if args.max_model_cases and model_done>=args.max_model_cases:
                results.append({"case_id":cid,"kind":kind,"status":"DEFERRED_BY_LIMIT","pass":None});continue
            try:
                r=probe_one(suite,overlay,cid,args.endpoint)
            except Exception as e:
                r={"case_id":cid,"kind":kind,"pass":False,"detail":{"code":"MODEL_ENDPOINT_ERROR","detail":repr(e)}}
            results.append(r); model_done+=1
            if r.get("pass") is False:
                # Frozen policy: stop at first real contradiction; expansion/re-design belongs back in Virtual.
                break
        report={"task_time_id":overlay["task_time_id"],"phase":"REAL","mode":"frontier",
                "active_ms":round((time.perf_counter()-t0)*1000,3),
                "results":results,
                "valid_real":all(x.get("pass") is not False for x in results if x.get("status")!="ADAPTER_JOB"),
                "reality_delta":"NONE" if all(x.get("pass") is not False for x in results) else "MODEL_CAPABILITY_CONTRADICTION",
                "action":"STOP_RETURN_GPT"}
        (out/"REALITY-FRONTIER-RESULT.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
        print(json.dumps(report,ensure_ascii=False,indent=2))


# ---- v4.6 long-context reality binding override ----
_build_fixture_base = build_fixture

def build_fixture(kind,unit,overlay):
    fx=_build_fixture_base(kind,unit,overlay)
    target=int(fx["token_envelope"]["prompt_target_tokens"])
    if kind in ("atomic","jev","thinking","long") and target >= 131072:
        h=int(stable_hash({"case_id":fx["case_id"],"seed":"CTX"})[:12],16)
        probe={"begin":1000+(h%8000),"middle":1000+((h//17)%8000),"end":1000+((h//37)%8000)}
        fx["context_probe"]=probe
        fx["expected"]=dict(fx["expected"])
        fx["expected"]["context_probe"]=probe
    return fx

def render_model_prompt(fx):
    compact={
      "case_id":fx["case_id"],
      "task":"Choose the exact frozen decision. Return one JSON object only. Do not redesign the plan.",
      "input":fx["input"],
      "required_output_keys":sorted(fx["expected"].keys())
    }
    if fx.get("context_probe"):
        compact["long_context_instruction"]="Read the three CTX_MARKER values embedded earlier in the prompt and return them unchanged in context_probe."
    return json.dumps(compact,ensure_ascii=False,separators=(",",":"))

def _tokenize_count(endpoint,text,timeout=300):
    body={"content":text,"add_special":False,"parse_special":True,"with_pieces":False}
    req=Request(endpoint.rstrip("/")+"/tokenize",
                data=json.dumps(body,separators=(",",":")).encode("utf-8"),
                headers={"Content-Type":"application/json"},method="POST")
    with urlopen(req,timeout=timeout) as r:
        obj=json.loads(r.read().decode("utf-8"))
    return len(obj.get("tokens",[]))

def build_padded_prompt(endpoint,fx):
    base=render_model_prompt(fx)
    target=int(fx["token_envelope"]["prompt_target_tokens"])
    # Small tasks need no synthetic context.
    if target <= 8192:
        return base,_tokenize_count(endpoint,base,60)
    block="alpha beta gamma delta epsilon zeta eta theta kappa lambda.\\n"
    block_tokens=max(1,_tokenize_count(endpoint,block,60))
    base_tokens=_tokenize_count(endpoint,base,60)
    wanted=max(0,target-base_tokens-64)
    n=max(0,wanted//block_tokens)
    probe=fx.get("context_probe")
    def make(nblocks):
        if not probe:
            return block*nblocks + "\\nTASK_PAYLOAD\\n" + base
        a=max(1,int(nblocks*0.05)); b=max(a+1,int(nblocks*0.50)); c=max(b+1,int(nblocks*0.90))
        chunks=[]
        for i in range(nblocks):
            if i==a: chunks.append(f"CTX_MARKER_BEGIN={probe['begin']}\\n")
            if i==b: chunks.append(f"CTX_MARKER_MIDDLE={probe['middle']}\\n")
            if i==c: chunks.append(f"CTX_MARKER_END={probe['end']}\\n")
            chunks.append(block)
        return "".join(chunks)+"\\nTASK_PAYLOAD\\n"+base
    prompt=make(n)
    count=_tokenize_count(endpoint,prompt,300)
    # Deterministic bounded correction: never exceed target/cap; approach target from below.
    for _ in range(4):
        if count > target:
            n=max(0,int(n*target/max(1,count))-2)
        elif count < int(target*0.97):
            n=max(n+1,int(n*target/max(1,count)))
        else:
            break
        prompt=make(n); count=_tokenize_count(endpoint,prompt,300)
    if count > target:
        # final monotonic trim
        while count > target and n>0:
            n=max(0,n-max(1,(count-target)//max(1,block_tokens)))
            prompt=make(n); count=_tokenize_count(endpoint,prompt,300)
    return prompt,count

def probe_one(suite,overlay,case_id,endpoint):
    table={u["id"]:(kind,u) for kind,u in flatten_units(suite)}
    if case_id not in table: raise SystemExit("unknown case id")
    kind,u=table[case_id]
    fx=build_fixture(kind,u,overlay)
    if kind in ("cache","memory"):
        return {"case_id":case_id,"status":"ADAPTER_JOB","handler":fx["handler"],"fixture":fx,
                "note":"runtime probe is executed by the frozen Bonsai runtime adapter"}
    prompt,prompt_tokens=build_padded_prompt(endpoint,fx)
    cap=int(fx["token_envelope"]["prompt_target_tokens"])
    if prompt_tokens>cap:
        return {"case_id":case_id,"kind":kind,"pass":False,
                "detail":{"code":"PROMPT_TOKEN_BUDGET_OVERFLOW","actual":prompt_tokens,"cap":cap}}
    resp,ms=post_completion(endpoint,prompt)
    text=extract_completion_text(resp)
    ok,detail=verify_model_result(fx,text)
    return {"case_id":case_id,"kind":kind,"pass":ok,"prompt_tokens":prompt_tokens,
            "prompt_target_tokens":cap,"e2e_ms":round(ms,3),"detail":detail,"output":text}

if __name__=="__main__":
    main()
