---
name: task-selection-priority-engine
description: 任务选择排序引擎 v0.2.0。运行链之外的项目准入、重大变化复审与项目组合优先级治理工具；默认不进入具体任务 Runtime，不计入具体任务 RUNTIME_T_VALID。
metadata:
  version: "0.2.0"
  display_name: "任务选择排序引擎"
  mother_method: "first-principles-physical-limit-convergence v4.7.2"
---

# 任务选择排序引擎 v0.2.0

## 1. 定位

本技能不是“极限短时间引擎”的运行时第 0 节点，而是运行链之外的治理工具。

只回答三件事：
1. `ADMISSION`：候选任务/项目值不值得正式立项。
2. `CONTINUATION`：出现重大新事实后，原立项依据是否仍成立。
3. `PORTFOLIO_PRIORITY`：已经通过准入且仍应继续的项目，现在先做哪个。

默认具体任务运行、循环、重试、Reality Delta、Virtual→Real 都不得重复调用本技能。

## 2. 母方法与唯一优化目标

研发与升级本技能时，按 `极限短时间引擎 v4.7.2` 的“一虚一实”执行：

`虚 -> 唯一冻结 -> 实`

对本技能实现方案的唯一优化锚：

`T* = min(T_VALID)`

质量、正确性、审计、架构一致性、证据充分性只是 VALID 硬门，不成为并列优化指标。

注意：项目本身的“价值/投入/置信度”是准入语义，不是本技能研发的第二优化目标。

## 3. 准入顺序

固定 fail-fast 顺序：

1. 反证/最强反方门：`falsification_passed`。
2. 战略整体适配门：`strategic_fit`。
3. 自动化架构适配门：`architecture_fit`。
4. 致命约束门：`fatal_constraint`。
5. 成熟现成方案替代门：覆盖足够且采用负担不高于自建，则 `USE_EXISTING`，不新立项目。
6. 证据置信度门：低置信度但存在 <= 完整项目总负担 10% 的 Kill Test，则仅 `PILOT`；否则 `KILL`。
7. 价值/总投入门：置信度调整后的归一化价值密度低于冻结阈值，`KILL`。
8. 全部通过才 `ADMIT`。

结果集合只有：`KILL / USE_EXISTING / PILOT / ADMIT`。

## 4. 总投入

`TOTAL_BURDEN = effort + maintenance + opportunity_cost`

它代表完整项目负担，不等同于货币收益，也不把“看起来有用”等同于“值得立项”。

## 5. 排序

只有 `ADMIT` 且处于活动状态的项目参与排序。

先满足已通过全部硬门的关键依赖，再按置信度调整后的价值密度与紧迫度排序；同分时优先更低总负担，再按既定进入顺序稳定决胜。

排序不会把一个未通过准入门的项目救回来。

## 6. 重大变化复审触发器

只有以下情况允许 `CONTINUATION`：
- `NEW_MATERIAL_EVIDENCE`
- `SCOPE_CHANGE`
- `VALUE_SHIFT`
- `EFFORT_SHIFT`
- `ARCHITECTURE_CHANGE`
- `MANUAL_REVIEW`

普通执行失败、普通重试、Reality Delta、任务内部循环都不是复审触发器。

## 7. 决策审计

每次有效决策必须保存：
- `decision_timestamp`：作出决定的时间。
- `evidence_as_of`：当时证据截止时间。
- `scope_hash`：冻结输入范围 SHA-256。
- `reason`：最小理由码。
- `admission / continuation / priority_rank`。

以后项目失败，先比较“当时已知证据下的立项依据”与后来出现的新事实，不得用事后信息伪装成当时已知。

## 8. Runtime 隔离

本技能自己的准入耗时可记录为 `T_ADMISSION_VALID`。

但它永远不计入已经批准的具体任务：
- `RUNTIME_T_VALID`
- `T*=min(T_VALID)`

## 9. 冻结实现

冻结目录：`frozen/v0.2.0/`

生产路径是标准库、无网络、无模型 API、无浏览器、无 Shell、无文件系统硬依赖的持久进程内函数。

固定现实验证基准：`TSPE-1000-STRUCTURED-E2E-01`。

一次 `T_VALID` 从 1000 个结构化候选项目进入冻结函数开始，到完整决策记录、优先级、时间字段、SHA-256 凭证全部生成并通过独立校验为止。
