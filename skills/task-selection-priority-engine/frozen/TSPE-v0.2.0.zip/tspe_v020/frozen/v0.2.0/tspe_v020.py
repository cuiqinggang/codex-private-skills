from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Sequence

ENGINE_VERSION = "0.2.0"

DEFAULT_POLICY: Dict[str, int] = {
    "min_confidence": 60,
    "min_value_density_bp": 7500,
    "max_pilot_fraction_bp": 1000,
    "existing_solution_min_coverage": 90,
}

ALLOWED_REVIEW_TRIGGERS = {
    "NEW_MATERIAL_EVIDENCE",
    "SCOPE_CHANGE",
    "VALUE_SHIFT",
    "EFFORT_SHIFT",
    "ARCHITECTURE_CHANGE",
    "MANUAL_REVIEW",
}

_REASON_HARD_FAIL = (
    ("falsification_passed", False, "FALSIFICATION_FAIL"),
    ("strategic_fit", False, "STRATEGIC_FIT_FAIL"),
    ("architecture_fit", False, "ARCHITECTURE_FIT_FAIL"),
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _bounded_int(project: Mapping[str, Any], key: str, lo: int, hi: int, default: Any = None) -> int:
    value = project[key] if default is None else project.get(key, default)
    if not isinstance(value, int) or isinstance(value, bool) or not (lo <= value <= hi):
        raise ValueError(f"{key} must be int in [{lo},{hi}]")
    return value


def _validate(project: Mapping[str, Any]) -> None:
    if not isinstance(project.get("id"), str) or not project["id"]:
        raise ValueError("id must be non-empty string")
    _bounded_int(project, "value", 0, 100)
    _bounded_int(project, "confidence", 0, 100)
    _bounded_int(project, "urgency", 0, 100)
    _bounded_int(project, "effort", 1, 100)
    _bounded_int(project, "maintenance", 0, 100, 0)
    _bounded_int(project, "opportunity_cost", 0, 100, 0)
    _bounded_int(project, "existing_solution_coverage", 0, 100, 0)
    _bounded_int(project, "existing_solution_burden", 0, 300, 300)
    _bounded_int(project, "kill_test_burden", 0, 100, 0)
    mode = project.get("mode", "ADMISSION")
    if mode not in {"ADMISSION", "CONTINUATION"}:
        raise ValueError("mode must be ADMISSION or CONTINUATION")
    if mode == "CONTINUATION" and project.get("review_trigger") not in ALLOWED_REVIEW_TRIGGERS:
        raise ValueError("CONTINUATION requires a material review_trigger")


def _burden(project: Mapping[str, Any]) -> int:
    return project["effort"] + project.get("maintenance", 0) + project.get("opportunity_cost", 0)


def _canonical_scope_hash(project: Mapping[str, Any]) -> str:
    fields = (
        project["id"],
        int(project.get("falsification_passed", True)),
        int(project.get("strategic_fit", True)),
        int(project.get("architecture_fit", True)),
        int(project.get("fatal_constraint", False)),
        project["value"],
        project["confidence"],
        project["urgency"],
        project["effort"],
        project.get("maintenance", 0),
        project.get("opportunity_cost", 0),
        project.get("existing_solution_coverage", 0),
        project.get("existing_solution_burden", 300),
        project.get("kill_test_burden", 0),
        int(project.get("critical_dependency", False)),
        project.get("evidence_as_of", ""),
    )
    raw = "\x1f".join(map(str, fields)).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _classify(project: Mapping[str, Any], policy: Mapping[str, int]) -> tuple[str, str, int]:
    burden = _burden(project)

    for key, bad_value, reason in _REASON_HARD_FAIL:
        if project.get(key, True) is bad_value:
            return "KILL", reason, burden
    if project.get("fatal_constraint", False):
        return "KILL", "FATAL_CONSTRAINT", burden

    if (
        project.get("existing_solution_coverage", 0) >= policy["existing_solution_min_coverage"]
        and project.get("existing_solution_burden", 300) <= burden
    ):
        return "USE_EXISTING", "MATURE_EXISTING_SOLUTION", burden

    confidence = project["confidence"]
    if confidence < policy["min_confidence"]:
        kill_test_burden = project.get("kill_test_burden", 0)
        if (
            kill_test_burden > 0
            and kill_test_burden * 10000 <= burden * policy["max_pilot_fraction_bp"]
        ):
            return "PILOT", "LOW_COST_KILL_TEST", burden
        return "KILL", "EVIDENCE_INSUFFICIENT", burden

    if project["value"] * confidence * 100 < burden * policy["min_value_density_bp"]:
        return "KILL", "VALUE_DENSITY_TOO_LOW", burden

    return "ADMIT", "ADMISSION_PASS", burden


def _continuation_from_admission(admission: str) -> str:
    if admission == "ADMIT":
        return "CONTINUE"
    if admission == "PILOT":
        return "HOLD_FOR_KILL_TEST"
    if admission == "USE_EXISTING":
        return "STOP_USE_EXISTING"
    return "KILL"


def evaluate_projects(
    projects: Sequence[Mapping[str, Any]],
    policy: Mapping[str, int] = DEFAULT_POLICY,
    decision_timestamp: str | None = None,
) -> Dict[str, Any]:
    """Frozen persistent in-process evaluator.

    No network/model/browser/shell/filesystem dependency. Validation, hard gates,
    audit receipt creation and portfolio ranking are compiled into one scan.
    """
    if decision_timestamp is None:
        decision_timestamp = _now_iso()

    records: List[MutableMapping[str, Any]] = []
    active: List[tuple[int, float, int, int, int]] = []
    seen: set[str] = set()
    append_record = records.append

    min_confidence = policy["min_confidence"]
    min_density_bp = policy["min_value_density_bp"]
    max_pilot_fraction_bp = policy["max_pilot_fraction_bp"]
    min_existing_coverage = policy["existing_solution_min_coverage"]

    for index, project in enumerate(projects):
        project_id = project.get("id")
        if not isinstance(project_id, str) or not project_id or project_id in seen:
            raise ValueError("id must be unique non-empty string")
        seen.add(project_id)

        value = project.get("value")
        confidence = project.get("confidence")
        urgency = project.get("urgency")
        effort = project.get("effort")
        maintenance = project.get("maintenance", 0)
        opportunity_cost = project.get("opportunity_cost", 0)
        existing_coverage = project.get("existing_solution_coverage", 0)
        existing_burden = project.get("existing_solution_burden", 300)
        kill_test_burden = project.get("kill_test_burden", 0)

        if not (
            type(value) is int and 0 <= value <= 100
            and type(confidence) is int and 0 <= confidence <= 100
            and type(urgency) is int and 0 <= urgency <= 100
            and type(effort) is int and 1 <= effort <= 100
            and type(maintenance) is int and 0 <= maintenance <= 100
            and type(opportunity_cost) is int and 0 <= opportunity_cost <= 100
            and type(existing_coverage) is int and 0 <= existing_coverage <= 100
            and type(existing_burden) is int and 0 <= existing_burden <= 300
            and type(kill_test_burden) is int and 0 <= kill_test_burden <= 100
        ):
            raise ValueError("numeric field outside frozen bounds")

        mode = project.get("mode", "ADMISSION")
        if mode not in {"ADMISSION", "CONTINUATION"}:
            raise ValueError("mode must be ADMISSION or CONTINUATION")
        if mode == "CONTINUATION" and project.get("review_trigger") not in ALLOWED_REVIEW_TRIGGERS:
            raise ValueError("CONTINUATION requires a material review_trigger")

        total_burden = effort + maintenance + opportunity_cost

        if not project.get("falsification_passed", True):
            admission, reason = "KILL", "FALSIFICATION_FAIL"
        elif not project.get("strategic_fit", True):
            admission, reason = "KILL", "STRATEGIC_FIT_FAIL"
        elif not project.get("architecture_fit", True):
            admission, reason = "KILL", "ARCHITECTURE_FIT_FAIL"
        elif project.get("fatal_constraint", False):
            admission, reason = "KILL", "FATAL_CONSTRAINT"
        elif existing_coverage >= min_existing_coverage and existing_burden <= total_burden:
            admission, reason = "USE_EXISTING", "MATURE_EXISTING_SOLUTION"
        elif confidence < min_confidence:
            if (
                kill_test_burden > 0
                and kill_test_burden * 10000 <= total_burden * max_pilot_fraction_bp
            ):
                admission, reason = "PILOT", "LOW_COST_KILL_TEST"
            else:
                admission, reason = "KILL", "EVIDENCE_INSUFFICIENT"
        elif value * confidence * 100 < total_burden * min_density_bp:
            admission, reason = "KILL", "VALUE_DENSITY_TOO_LOW"
        else:
            admission, reason = "ADMIT", "ADMISSION_PASS"

        continuation = _continuation_from_admission(admission) if mode == "CONTINUATION" else None
        record_index = len(records)
        append_record(
            {
                "project_id": project_id,
                "mode": mode,
                "admission": admission,
                "continuation": continuation,
                "reason": reason,
                "priority_rank": None,
                "decision_timestamp": project.get("decision_timestamp", decision_timestamp),
                "evidence_as_of": project.get("evidence_as_of", decision_timestamp),
                "scope_hash": _canonical_scope_hash(project),
            }
        )

        if admission == "ADMIT" and (mode == "ADMISSION" or continuation == "CONTINUE"):
            density = (value * confidence * urgency) / total_burden
            active.append(
                (
                    1 if project.get("critical_dependency", False) else 0,
                    density,
                    -total_burden,
                    -int(project.get("age_seq", record_index)),
                    record_index,
                )
            )

    active.sort(reverse=True)
    for rank, item in enumerate(active, 1):
        records[item[4]]["priority_rank"] = rank

    return {"engine_version": ENGINE_VERSION, "policy": dict(policy), "records": records}

def evaluate_json(payload_json: str) -> str:
    payload = json.loads(payload_json)
    projects = payload.get("projects")
    if not isinstance(projects, list):
        raise ValueError("payload.projects must be a list")
    result = evaluate_projects(projects, decision_timestamp=payload.get("decision_timestamp"))
    return json.dumps(result, ensure_ascii=False, separators=(",", ":"))
