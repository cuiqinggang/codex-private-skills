from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path
from time import perf_counter_ns

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tspe_v020 import evaluate_json

FIXTURES = HERE / "GOLDEN-FIXTURES-v0.2.0.json"


def golden_verify() -> None:
    raw = json.loads(FIXTURES.read_text(encoding="utf-8"))
    expected = {p["id"]: p for p in raw["projects"]}
    payload = {"decision_timestamp": raw["decision_timestamp"], "projects": [{k:v for k,v in p.items() if not k.startswith("expected")} for p in raw["projects"]]}
    result = json.loads(evaluate_json(json.dumps(payload, ensure_ascii=False, separators=(",", ":"))))
    records = {r["project_id"]: r for r in result["records"]}
    if set(records) != set(expected):
        raise AssertionError("fixture coverage mismatch")
    for pid, exp in expected.items():
        got = records[pid]
        if got["admission"] != exp["expected"]:
            raise AssertionError(f"{pid}: {got['admission']} != {exp['expected']}")
        if "expected_rank" in exp and got["priority_rank"] != exp["expected_rank"]:
            raise AssertionError(f"{pid}: rank {got['priority_rank']} != {exp['expected_rank']}")
        if "expected_continuation" in exp and got["continuation"] != exp["expected_continuation"]:
            raise AssertionError(f"{pid}: continuation mismatch")
        if len(got["scope_hash"]) != 64:
            raise AssertionError(f"{pid}: invalid scope hash")


def benchmark_payload() -> str:
    raw = json.loads(FIXTURES.read_text(encoding="utf-8"))
    seeds = [{k:v for k,v in p.items() if not k.startswith("expected")} for p in raw["projects"]]
    projects = []
    for i in range(1000):
        p = dict(seeds[i % len(seeds)])
        p["id"] = f"B{i:04d}-{p['id']}"
        p["age_seq"] = i
        if p["mode"] == "CONTINUATION":
            p["review_trigger"] = "NEW_MATERIAL_EVIDENCE"
        projects.append(p)
    return json.dumps({"decision_timestamp": raw["decision_timestamp"], "projects": projects}, ensure_ascii=False, separators=(",", ":"))


def verify_batch(output_json: str) -> None:
    result = json.loads(output_json)
    records = result["records"]
    if len(records) != 1000:
        raise AssertionError("coverage != 1000")
    ids = [r["project_id"] for r in records]
    if len(ids) != len(set(ids)):
        raise AssertionError("duplicate output id")
    ranks = [r["priority_rank"] for r in records if r["priority_rank"] is not None]
    if sorted(ranks) != list(range(1, len(ranks)+1)):
        raise AssertionError("rank sequence invalid")
    if any(len(r["scope_hash"]) != 64 for r in records):
        raise AssertionError("scope hash invalid")


def main() -> int:
    golden_verify()
    payload = benchmark_payload()

    for _ in range(3):
        verify_batch(evaluate_json(payload))

    times = []
    valid = 0
    for _ in range(30):
        t0 = perf_counter_ns()
        output = evaluate_json(payload)
        elapsed_ms = (perf_counter_ns() - t0) / 1_000_000
        verify_batch(output)
        valid += 1
        times.append(elapsed_ms)

    ordered = sorted(times)
    p95 = ordered[max(0, int(len(ordered) * 0.95) - 1)]
    print("ENGINE=task-selection-priority-engine")
    print("VERSION=0.2.0")
    print("BENCHMARK=TSPE-1000-STRUCTURED-E2E-01")
    print("WARMUP_RUNS=3")
    print("REAL_RUNS=30")
    print(f"VALID_RUNS={valid}")
    print(f"T_VALID_MIN_MS={min(times):.6f}")
    print(f"T_VALID_P50_MS={statistics.median(times):.6f}")
    print(f"T_VALID_P95_MS={p95:.6f}")
    print(f"T_VALID_MAX_MS={max(times):.6f}")
    print("GOLDEN_GATE=PASS")
    print("AUDIT_TIMESTAMP_GATE=PASS")
    print("SCOPE_HASH_GATE=PASS")
    print("PORTFOLIO_RANK_GATE=PASS")
    print("FINAL_VALID=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
