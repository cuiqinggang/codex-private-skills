# Task Selection & Priority Engine v0.2.0 — Virtual Maturity Freeze

## 母方法
`first-principles-physical-limit-convergence v4.7.2`

## 任务边界
本技能只做：
- `ADMISSION`：项目准入；
- `CONTINUATION`：重大新事实后的继续/停止复审；
- `PORTFOLIO_PRIORITY`：通过准入项目的当前优先级。

它不进入具体任务 Runtime，不进入 Virtual→Real 内部循环，不计入具体任务 `RUNTIME_T_VALID`。

## 成熟方案组件
- Stage-Gate：Go/Kill/Hold 与项目组合治理思想。
- RICE：Impact / Confidence / Effort 的一致化优先级思想；不直接照搬为“高分必立项”。
- Portfolio Management：只有先通过独立项目硬门的项目才进入项目组合排序。
- Decision Record：冻结 `decision_timestamp + evidence_as_of + scope_hash + reason`，用于以后按“当时已知信息”复盘。

## 冻结业务顺序
`反证门 → 战略/架构硬门 → 致命约束 → 成熟现成方案替代 → 低成本 Kill Test → 价值/总投入门 → ADMIT → Portfolio Rank`

“很有用”不等于“值得单独立项”；未通过整体架构硬门的项目在排序之前即被淘汰。

## 唯一实现优化目标
所有候选先过完全相同的有效硬门，然后只比较：

`T* = min(T_VALID)`

固定基准：`TSPE-1000-STRUCTURED-E2E-01`

单次 `T_VALID` 从 1000 个结构化候选项目进入冻结接口开始，到完整准入/复审/排序、时间字段、SHA-256 立项凭证全部生成并通过验证为止。

## 同基准候选竞争
最终基准上的有效候选预跑：

| Candidate | 结构 | min T_VALID |
|---|---|---:|
| A | 通用规则表 + Fraction 精确分数 | 8.663938 ms |
| B | 两遍扫描 + 浮点 tuple 排序 | 7.257936 ms |
| E | 单遍 fail-fast + 内联字段门 + 同步审计记录 | 6.414963 ms |

`WINNER=E`

## 冻结候选 E 删除的冗余
- 通用规则对象与 Fraction 对象分配；
- 第二遍 ID→项目回查；
- 独立的通用 schema 函数调用链；
- 与最终输出无关的中间结构。

同时保留全部必要功能：
- `KILL / USE_EXISTING / PILOT / ADMIT`；
- `CONTINUE / HOLD_FOR_KILL_TEST / STOP_USE_EXISTING / KILL`；
- 关键依赖与项目池排序；
- `decision_timestamp`；
- `evidence_as_of`；
- `scope_hash`；
- 最小 reason code。

## 虚拟正确性
- 8 类 golden fixture：PASS。
- 10,000 个确定性随机项目，与独立慢速精确参考实现比较：`SEMANTIC_EQUIVALENCE=PASS`。
- CLI 独立项目样例：`architecture_fit=false -> KILL`。
- 成熟现成方案覆盖充分且采用负担更低：`USE_EXISTING`。
- 低置信度 + Kill Test ≤ 完整项目负担 10%：`PILOT`。
- 低置信度 + Kill Test 过贵：`KILL`。
- 重大新证据导致价值密度塌缩：继续性复审 `KILL`。

## GPT 执行环境真实预跑
冻结候选 E 运行 `3 warmup + 30 measured`：

- `VALID_RUNS=30/30`
- `T_VALID_MIN_MS=6.448333`
- `T_VALID_P50_MS=7.051018`
- `T_VALID_P95_MS=9.680503`
- `T_VALID_MAX_MS=10.030460`
- `FINAL_VALID=PASS`

虚拟最短锚 `6.414963 ms` 与真实预跑最短 `6.448333 ms` 相差 `+0.033370 ms`（约 +0.52%）。语义与有效门无 Reality Delta。

## 冻结
- `VIRTUAL_MATURITY=PASS`
- `EXECUTION_CHAIN_CLOSED=PASS`
- `EXTERNAL_DEPENDENCIES_CLOSED=PASS`
- `FROZEN_SOLUTION=PASS`
- `FREEZE_ID=TSPE-v0.2.0-E-INLINE-ONEPASS`

最终用户 Windows/Codex 环境只允许执行冻结 `REAL-VERIFY-v0.2.0.py`；不得现场改规则、改阈值或换候选。
